#!/usr/bin/env python
"""
ACT (Action Chunking Transformer) with Vision Transformer backbone.

This is a modified version of ACT that replaces ResNet with ViT for image encoding.
The key difference is that ViT processes images as patches, preserving spatial
information in a way that may better integrate with coordinate conditioning.

Based on LeRobot's ACT implementation.
"""

import math
from collections import deque
from collections.abc import Callable
from itertools import chain

import einops
import numpy as np
import torch
import torch.nn.functional as F
import torchvision
from torch import Tensor, nn

from lerobot.policies.act.configuration_act import ACTConfig
from lerobot.policies.pretrained import PreTrainedPolicy
from lerobot.utils.constants import ACTION, OBS_ENV_STATE, OBS_IMAGES, OBS_STATE


class ACTViTPolicy(PreTrainedPolicy):
    """
    Action Chunking Transformer Policy with Vision Transformer backbone.

    Key difference from standard ACT: Uses ViT instead of ResNet for image encoding.
    ViT processes images as patches (e.g., 16x16), outputting one token per patch.
    This preserves spatial information and may integrate better with coordinate conditioning.
    """

    config_class = ACTConfig
    name = "act_vit"

    @classmethod
    def from_pretrained(cls, model_path: str, vit_model: str = None, **kwargs):
        """Load pretrained ACT-ViT model.

        Args:
            model_path: Path to the pretrained model directory
            vit_model: Optional ViT model variant (e.g., 'vit_b_16', 'vit_b_32').
                      If provided, overrides the default when creating the model.
        """
        import os
        import json
        import draccus
        from safetensors.torch import load_model as load_model_as_safetensor

        # Load config JSON and remove 'type' field before parsing
        config_path = os.path.join(model_path, "config.json")
        with open(config_path) as f:
            config_dict = json.load(f)

        # Remove 'type' field which draccus doesn't accept
        config_dict.pop('type', None)

        # Use draccus decode to create config from dict
        config = draccus.decode(ACTConfig, config_dict)

        # Set device
        if config.device is None:
            config.device = "cuda" if torch.cuda.is_available() else "cpu"

        # Set vit_model on config if provided
        if vit_model:
            config.vit_model = vit_model

        # Detect completion head and blinkering from training metadata
        training_meta_path = os.path.join(model_path, "training_metadata.json")
        if os.path.exists(training_meta_path):
            import json
            with open(training_meta_path) as f:
                training_meta = json.load(f)
            if training_meta.get("completion_head"):
                config.use_completion_head = True
                config.completion_loss_weight = training_meta.get("completion_weight", 0.1)
            if training_meta.get("blinkering"):
                config.blinkering = True

        # Create model instance
        instance = cls(config)

        # Load weights
        model_file = os.path.join(model_path, "model.safetensors")
        print("Loading weights from local directory")
        load_model_as_safetensor(instance, model_file)

        return instance

    def __init__(self, config: ACTConfig):
        super().__init__(config)
        config.validate_features()
        self.config = config

        self.model = ACTViT(config)

        if config.temporal_ensemble_coeff is not None:
            self.temporal_ensembler = ACTTemporalEnsembler(config.temporal_ensemble_coeff, config.chunk_size)

        self.reset()

    def get_optim_params(self) -> dict:
        return [
            {
                "params": [
                    p for n, p in self.named_parameters()
                    if not n.startswith("model.backbone") and p.requires_grad
                ]
            },
            {
                "params": [
                    p for n, p in self.named_parameters()
                    if n.startswith("model.backbone") and p.requires_grad
                ],
                "lr": self.config.optimizer_lr_backbone,
            },
        ]

    def reset(self):
        """This should be called whenever the environment is reset."""
        if self.config.temporal_ensemble_coeff is not None:
            self.temporal_ensembler.reset()
        else:
            self._action_queue = deque([], maxlen=self.config.n_action_steps)
            self._completion_queue = deque([], maxlen=self.config.n_action_steps)

    @torch.no_grad()
    def select_action(self, batch: dict[str, Tensor]) -> Tensor:
        """Select a single action given environment observations."""
        self.eval()

        if self.config.temporal_ensemble_coeff is not None:
            actions, _ = self.predict_action_chunk(batch)
            action = self.temporal_ensembler.update(actions)
            return action

        if len(self._action_queue) == 0:
            actions, completion = self.predict_action_chunk(batch)
            actions = actions[:, : self.config.n_action_steps]
            self._action_queue.extend(actions.transpose(0, 1))
            if completion is not None:
                completion = completion[:, : self.config.n_action_steps]
                self._completion_queue.extend(completion.transpose(0, 1))
        return self._action_queue.popleft()

    @torch.no_grad()
    def select_action_with_completion(self, batch: dict[str, Tensor]) -> tuple[Tensor, float | None]:
        """Select action and return completion progress.

        Returns (action, completion_progress) where completion_progress is a float
        in [0, 1] or None if no completion head.
        """
        self.eval()

        if len(self._action_queue) == 0:
            actions, completion = self.predict_action_chunk(batch)
            actions = actions[:, : self.config.n_action_steps]
            self._action_queue.extend(actions.transpose(0, 1))
            if completion is not None:
                completion = completion[:, : self.config.n_action_steps]
                self._completion_queue.extend(completion.transpose(0, 1))

        action = self._action_queue.popleft()
        progress = None
        if len(self._completion_queue) > 0:
            progress_tensor = self._completion_queue.popleft()
            progress = progress_tensor.mean().item()  # Average across batch dim

        return action, progress

    @torch.no_grad()
    def predict_action_chunk(self, batch: dict[str, Tensor]) -> tuple[Tensor, Tensor | None]:
        """Predict a chunk of actions (and optionally completion) given environment observations."""
        self.eval()

        if self.config.image_features:
            batch = dict(batch)
            batch[OBS_IMAGES] = [batch[key] for key in self.config.image_features]

        result = self.model(batch)
        actions = result[0]
        completion = result[2] if len(result) > 2 else None
        return actions, completion

    def forward(self, batch: dict[str, Tensor]) -> tuple[Tensor, dict]:
        """Run the batch through the model and compute the loss for training or validation."""
        if self.config.image_features:
            batch = dict(batch)
            batch[OBS_IMAGES] = [batch[key] for key in self.config.image_features]

        actions_hat, (mu_hat, log_sigma_x2_hat), completion_hat = self.model(batch)

        # Base mask: ignore padded actions
        not_padded = ~batch["action_is_pad"].unsqueeze(-1)  # (B, chunk, 1)

        # Subtask chunk masking: also mask actions beyond current subtask boundary
        if "action_mask" in batch:
            subtask_mask = batch["action_mask"].unsqueeze(-1)  # (B, chunk, 1)
            combined_mask = not_padded * subtask_mask
        else:
            combined_mask = not_padded

        l1_loss = (
            F.l1_loss(batch[ACTION], actions_hat, reduction="none") * combined_mask
        ).sum() / combined_mask.sum().clamp(min=1)

        loss_dict = {"l1_loss": l1_loss.item()}

        if self.config.use_vae:
            mean_kld = (
                (-0.5 * (1 + log_sigma_x2_hat - mu_hat.pow(2) - (log_sigma_x2_hat).exp())).sum(-1).mean()
            )
            loss_dict["kld_loss"] = mean_kld.item()
            loss = l1_loss + mean_kld * self.config.kl_weight
        else:
            loss = l1_loss

        # Completion loss (not masked — progress=1.0 after boundary is valid signal)
        if completion_hat is not None and "completion_progress" in batch:
            completion_target = batch["completion_progress"]  # (B, chunk)
            completion_loss = F.mse_loss(completion_hat, completion_target)
            completion_weight = getattr(self.config, 'completion_loss_weight', 0.1)
            loss = loss + completion_weight * completion_loss
            loss_dict["completion_loss"] = completion_loss.item()

        return loss, loss_dict


class ACTTemporalEnsembler:
    """Temporal ensembling as described in ACT paper."""

    def __init__(self, temporal_ensemble_coeff: float, chunk_size: int) -> None:
        self.chunk_size = chunk_size
        self.ensemble_weights = torch.exp(-temporal_ensemble_coeff * torch.arange(chunk_size))
        self.ensemble_weights_cumsum = torch.cumsum(self.ensemble_weights, dim=0)
        self.reset()

    def reset(self):
        self.ensembled_actions = None
        self.ensembled_actions_count = None

    def update(self, actions: Tensor) -> Tensor:
        self.ensemble_weights = self.ensemble_weights.to(device=actions.device)
        self.ensemble_weights_cumsum = self.ensemble_weights_cumsum.to(device=actions.device)

        if self.ensembled_actions is None:
            self.ensembled_actions = actions.clone()
            self.ensembled_actions_count = torch.ones(
                (self.chunk_size, 1), dtype=torch.long, device=self.ensembled_actions.device
            )
        else:
            self.ensembled_actions *= self.ensemble_weights_cumsum[self.ensembled_actions_count - 1]
            self.ensembled_actions += actions[:, :-1] * self.ensemble_weights[self.ensembled_actions_count]
            self.ensembled_actions /= self.ensemble_weights_cumsum[self.ensembled_actions_count]
            self.ensembled_actions_count = torch.clamp(self.ensembled_actions_count + 1, max=self.chunk_size)
            self.ensembled_actions = torch.cat([self.ensembled_actions, actions[:, -1:]], dim=1)
            self.ensembled_actions_count = torch.cat(
                [self.ensembled_actions_count, torch.ones_like(self.ensembled_actions_count[-1:])]
            )

        action, self.ensembled_actions, self.ensembled_actions_count = (
            self.ensembled_actions[:, 0],
            self.ensembled_actions[:, 1:],
            self.ensembled_actions_count[1:],
        )
        return action


class ViTBackbone(nn.Module):
    """
    Vision Transformer backbone for image feature extraction.

    Uses torchvision's ViT but removes the classification head and returns
    patch tokens instead. Images are resized to 224x224 before processing.
    """

    def __init__(self, model_name: str = "vit_b_16", pretrained: bool = True, freeze: bool = False):
        super().__init__()

        self.image_size = 224  # ViT expected input size

        # Load pretrained ViT
        if model_name == "vit_b_16":
            weights = torchvision.models.ViT_B_16_Weights.IMAGENET1K_V1 if pretrained else None
            self.vit = torchvision.models.vit_b_16(weights=weights)
            self.hidden_dim = 768
            self.patch_size = 16
        elif model_name == "vit_b_32":
            weights = torchvision.models.ViT_B_32_Weights.IMAGENET1K_V1 if pretrained else None
            self.vit = torchvision.models.vit_b_32(weights=weights)
            self.hidden_dim = 768
            self.patch_size = 32
        elif model_name == "vit_l_16":
            weights = torchvision.models.ViT_L_16_Weights.IMAGENET1K_V1 if pretrained else None
            self.vit = torchvision.models.vit_l_16(weights=weights)
            self.hidden_dim = 1024
            self.patch_size = 16
        else:
            raise ValueError(f"Unknown ViT model: {model_name}")

        # Number of patches for 224x224 image
        self.num_patches = (self.image_size // self.patch_size) ** 2  # 14x14 = 196 for patch_size=16

        # Remove classification head - we want patch tokens
        self.vit.heads = nn.Identity()

        if freeze:
            for param in self.vit.parameters():
                param.requires_grad = False

    def forward(self, x: Tensor) -> Tensor:
        """
        Args:
            x: (B, C, H, W) input images (any size)

        Returns:
            (B, num_patches, hidden_dim) patch tokens (excluding CLS token)
            For ViT-B/16 with 224x224: (B, 196, 768)
        """
        B, C, H, W = x.shape

        # Resize to 224x224 if needed
        if H != self.image_size or W != self.image_size:
            x = F.interpolate(x, size=(self.image_size, self.image_size), mode='bilinear', align_corners=False)

        # Use ViT's forward up to the encoder output
        # 1. Patch embedding
        x = self.vit._process_input(x)  # (B, num_patches, hidden_dim)

        # 2. Add class token
        batch_class_token = self.vit.class_token.expand(B, -1, -1)
        x = torch.cat([batch_class_token, x], dim=1)

        # 3. Add positional embedding (no interpolation needed since we resize to 224x224)
        x = x + self.vit.encoder.pos_embedding

        # 4. Apply transformer encoder
        x = self.vit.encoder.ln(self.vit.encoder.layers(self.vit.encoder.dropout(x)))

        # 5. Return patch tokens (exclude CLS token at position 0)
        patch_tokens = x[:, 1:, :]  # (B, 196, 768)

        return patch_tokens


class ACTViT(nn.Module):
    """
    Action Chunking Transformer with ViT backbone.

    Architecture differences from standard ACT:
    - Uses ViT instead of ResNet for image encoding
    - ViT outputs patch tokens directly (no spatial feature map)
    - Each patch token represents a 16x16 or 32x32 region of the image
    """

    def __init__(self, config: ACTConfig):
        super().__init__()
        self.config = config
        self.blinkering = getattr(config, 'blinkering', False)

        # VAE encoder (same as standard ACT)
        if self.config.use_vae:
            self.vae_encoder = ACTEncoder(config, is_vae_encoder=True)
            self.vae_encoder_cls_embed = nn.Embedding(1, config.dim_model)
            if self.config.robot_state_feature:
                self.vae_encoder_robot_state_input_proj = nn.Linear(
                    self.config.robot_state_feature.shape[0], config.dim_model
                )
            self.vae_encoder_action_input_proj = nn.Linear(
                self.config.action_feature.shape[0],
                config.dim_model,
            )
            self.vae_encoder_latent_output_proj = nn.Linear(config.dim_model, config.latent_dim * 2)
            num_input_token_encoder = 1 + config.chunk_size
            if self.config.robot_state_feature:
                num_input_token_encoder += 1
            self.register_buffer(
                "vae_encoder_pos_enc",
                create_sinusoidal_pos_embedding(num_input_token_encoder, config.dim_model).unsqueeze(0),
            )

        # ViT backbone for image feature extraction
        # Model name can be passed via config.vit_model custom attribute
        # Default to vit_b_16 if not specified
        vit_model_name = getattr(config, 'vit_model', 'vit_b_16')
        if self.config.image_features:
            self.backbone = ViTBackbone(
                model_name=vit_model_name,
                pretrained=config.pretrained_backbone_weights is not None,
                freeze=False,
            )
            # Project ViT hidden dim to ACT model dim
            self.encoder_img_feat_input_proj = nn.Linear(self.backbone.hidden_dim, config.dim_model)

        # Transformer encoder/decoder (same as standard ACT)
        self.encoder = ACTEncoder(config)
        self.decoder = ACTDecoder(config)

        # Input projections
        if self.config.robot_state_feature:
            self.encoder_robot_state_input_proj = nn.Linear(
                self.config.robot_state_feature.shape[0], config.dim_model
            )
        if self.config.env_state_feature:
            self.encoder_env_state_input_proj = nn.Linear(
                self.config.env_state_feature.shape[0], config.dim_model
            )
        self.encoder_latent_input_proj = nn.Linear(config.latent_dim, config.dim_model)

        # Positional embeddings
        n_1d_tokens = 1  # for the latent
        if self.config.robot_state_feature:
            n_1d_tokens += 1
        if self.config.env_state_feature:
            n_1d_tokens += 1
        self.encoder_1d_feature_pos_embed = nn.Embedding(n_1d_tokens, config.dim_model)

        # Learnable position embeddings for ViT patch tokens
        # ViT-B/16 with 224x224 images = 14x14 = 196 patches per camera
        if self.config.image_features:
            self.num_patches_per_camera = self.backbone.num_patches
            self.encoder_vit_pos_embed = nn.Embedding(self.num_patches_per_camera, config.dim_model)
            # Learnable camera embeddings to distinguish patches from different cameras
            # Each camera gets a unique embedding added to all its patches
            num_cameras = len(self.config.image_features)
            self.encoder_camera_embed = nn.Embedding(num_cameras, config.dim_model)

        # Decoder positional embeddings
        self.decoder_pos_embed = nn.Embedding(config.chunk_size, config.dim_model)

        # Action prediction head
        self.action_head = nn.Linear(config.dim_model, self.config.action_feature.shape[0])

        # Completion prediction head (predicts subtask progress 0→1 per chunk step)
        self.use_completion_head = getattr(config, 'use_completion_head', False)
        if self.use_completion_head:
            self.completion_head = nn.Sequential(
                nn.Linear(config.dim_model, 64),
                nn.ReLU(),
                nn.Linear(64, 1),
                nn.Sigmoid(),
            )

        self._reset_parameters()

    def _reset_parameters(self):
        for p in chain(self.encoder.parameters(), self.decoder.parameters()):
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def forward(self, batch: dict[str, Tensor]) -> tuple[Tensor, tuple[Tensor, Tensor] | tuple[None, None]]:
        if self.config.use_vae and self.training:
            assert ACTION in batch

        batch_size = batch[OBS_IMAGES][0].shape[0] if OBS_IMAGES in batch else batch[OBS_ENV_STATE].shape[0]

        # VAE encoding (same as standard ACT)
        if self.config.use_vae and ACTION in batch and self.training:
            cls_embed = einops.repeat(
                self.vae_encoder_cls_embed.weight, "1 d -> b 1 d", b=batch_size
            )
            if self.config.robot_state_feature:
                robot_state_embed = self.vae_encoder_robot_state_input_proj(batch[OBS_STATE])
                robot_state_embed = robot_state_embed.unsqueeze(1)
            action_embed = self.vae_encoder_action_input_proj(batch[ACTION])

            if self.config.robot_state_feature:
                vae_encoder_input = [cls_embed, robot_state_embed, action_embed]
            else:
                vae_encoder_input = [cls_embed, action_embed]
            vae_encoder_input = torch.cat(vae_encoder_input, axis=1)

            pos_embed = self.vae_encoder_pos_enc.clone().detach()
            cls_joint_is_pad = torch.full(
                (batch_size, 2 if self.config.robot_state_feature else 1),
                False,
                device=batch[OBS_STATE].device,
            )
            key_padding_mask = torch.cat([cls_joint_is_pad, batch["action_is_pad"]], axis=1)

            cls_token_out = self.vae_encoder(
                vae_encoder_input.permute(1, 0, 2),
                pos_embed=pos_embed.permute(1, 0, 2),
                key_padding_mask=key_padding_mask,
            )[0]
            latent_pdf_params = self.vae_encoder_latent_output_proj(cls_token_out)
            mu = latent_pdf_params[:, : self.config.latent_dim]
            log_sigma_x2 = latent_pdf_params[:, self.config.latent_dim :]
            latent_sample = mu + log_sigma_x2.div(2).exp() * torch.randn_like(mu)
        else:
            mu = log_sigma_x2 = None
            latent_sample = torch.zeros([batch_size, self.config.latent_dim], dtype=torch.float32).to(
                batch[OBS_STATE].device if OBS_STATE in batch else batch[OBS_IMAGES][0].device
            )

        # Build encoder input tokens
        # All tokens will be shape (seq, batch, dim) after stacking

        # 1D tokens: latent, robot_state, env_state
        tokens_1d = [self.encoder_latent_input_proj(latent_sample)]  # (B, dim_model)
        if self.config.robot_state_feature:
            tokens_1d.append(self.encoder_robot_state_input_proj(batch[OBS_STATE]))
        if self.config.env_state_feature:
            tokens_1d.append(self.encoder_env_state_input_proj(batch[OBS_ENV_STATE]))

        # Stack 1D tokens: (n_1d_tokens, B, dim_model)
        tokens_1d = torch.stack(tokens_1d, dim=0)
        pos_1d = self.encoder_1d_feature_pos_embed.weight.unsqueeze(1)  # (n_1d_tokens, 1, dim_model)

        # Process images through ViT
        all_patch_tokens = []
        all_patch_pos = []

        if self.config.image_features:
            for cam_idx, img in enumerate(batch[OBS_IMAGES]):
                # ViT returns (B, num_patches, hidden_dim)
                patch_tokens = self.backbone(img)  # (B, 196, 768)

                # Project to model dimension
                patch_tokens = self.encoder_img_feat_input_proj(patch_tokens)  # (B, 196, dim_model)

                # Rearrange to (num_patches, B, dim_model)
                patch_tokens = patch_tokens.permute(1, 0, 2)

                # Position embeddings for patches (shared across cameras)
                patch_pos = self.encoder_vit_pos_embed.weight.unsqueeze(1)  # (196, 1, dim_model)

                # Add camera embedding to distinguish which camera these patches came from
                camera_embed = self.encoder_camera_embed.weight[cam_idx]  # (dim_model,)
                patch_pos = patch_pos + camera_embed.unsqueeze(0).unsqueeze(1)  # (196, 1, dim_model)

                all_patch_tokens.append(patch_tokens)
                all_patch_pos.append(patch_pos)

        # Concatenate all tokens along sequence dimension
        if all_patch_tokens:
            patch_tokens_cat = torch.cat(all_patch_tokens, dim=0)  # (num_cameras * 196, B, dim_model)
            patch_pos_cat = torch.cat(all_patch_pos, dim=0)  # (num_cameras * 196, 1, dim_model)

            encoder_in_tokens = torch.cat([tokens_1d, patch_tokens_cat], dim=0)
            encoder_in_pos_embed = torch.cat([pos_1d, patch_pos_cat], dim=0)
        else:
            encoder_in_tokens = tokens_1d
            encoder_in_pos_embed = pos_1d

        # Blinkering: mask overhead camera tokens during PICK_UP (1) and DROP (3) subtasks
        blinkering_mask = None
        if self.blinkering and OBS_ENV_STATE in batch and len(all_patch_tokens) > 1:
            env_state = batch[OBS_ENV_STATE]
            subtask_onehot = env_state[:, -4:]  # Last 4 dims = subtask one-hot
            subtask_idx = subtask_onehot.argmax(dim=1)
            should_blinker = (subtask_idx == 1) | (subtask_idx == 3)  # PICK_UP or DROP

            if should_blinker.any():
                seq_len = encoder_in_tokens.shape[0]
                blinkering_mask = torch.zeros(batch_size, seq_len, dtype=torch.bool,
                                              device=encoder_in_tokens.device)
                # Mask all cameras except first (wrist) — tokens_1d covers latent+state+env_state,
                # then first camera's patches, then overhead camera's patches
                overhead_start = tokens_1d.shape[0] + self.num_patches_per_camera
                blinkering_mask[should_blinker, overhead_start:] = True

        # Forward through encoder
        encoder_out = self.encoder(encoder_in_tokens, pos_embed=encoder_in_pos_embed,
                                   key_padding_mask=blinkering_mask)

        # Forward through decoder
        decoder_in = torch.zeros(
            (self.config.chunk_size, batch_size, self.config.dim_model),
            dtype=encoder_in_pos_embed.dtype,
            device=encoder_in_pos_embed.device,
        )
        decoder_out = self.decoder(
            decoder_in,
            encoder_out,
            encoder_pos_embed=encoder_in_pos_embed,
            decoder_pos_embed=self.decoder_pos_embed.weight.unsqueeze(1),
            memory_key_padding_mask=blinkering_mask,
        )

        decoder_out = decoder_out.transpose(0, 1)
        actions = self.action_head(decoder_out)

        # Completion head: predict subtask progress per chunk step
        completion = None
        if self.use_completion_head:
            completion = self.completion_head(decoder_out).squeeze(-1)  # (batch, chunk_size)

        return actions, (mu, log_sigma_x2), completion


# Encoder/Decoder classes (copied from standard ACT)
class ACTEncoder(nn.Module):
    def __init__(self, config: ACTConfig, is_vae_encoder: bool = False):
        super().__init__()
        self.is_vae_encoder = is_vae_encoder
        num_layers = config.n_vae_encoder_layers if self.is_vae_encoder else config.n_encoder_layers
        self.layers = nn.ModuleList([ACTEncoderLayer(config) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(config.dim_model) if config.pre_norm else nn.Identity()

    def forward(self, x: Tensor, pos_embed: Tensor | None = None, key_padding_mask: Tensor | None = None) -> Tensor:
        for layer in self.layers:
            x = layer(x, pos_embed=pos_embed, key_padding_mask=key_padding_mask)
        x = self.norm(x)
        return x


class ACTEncoderLayer(nn.Module):
    def __init__(self, config: ACTConfig):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(config.dim_model, config.n_heads, dropout=config.dropout)
        self.linear1 = nn.Linear(config.dim_model, config.dim_feedforward)
        self.dropout = nn.Dropout(config.dropout)
        self.linear2 = nn.Linear(config.dim_feedforward, config.dim_model)
        self.norm1 = nn.LayerNorm(config.dim_model)
        self.norm2 = nn.LayerNorm(config.dim_model)
        self.dropout1 = nn.Dropout(config.dropout)
        self.dropout2 = nn.Dropout(config.dropout)
        self.activation = get_activation_fn(config.feedforward_activation)
        self.pre_norm = config.pre_norm

    def forward(self, x, pos_embed: Tensor | None = None, key_padding_mask: Tensor | None = None) -> Tensor:
        skip = x
        if self.pre_norm:
            x = self.norm1(x)
        q = k = x if pos_embed is None else x + pos_embed
        x = self.self_attn(q, k, value=x, key_padding_mask=key_padding_mask)
        x = x[0]
        x = skip + self.dropout1(x)
        if self.pre_norm:
            skip = x
            x = self.norm2(x)
        else:
            x = self.norm1(x)
            skip = x
        x = self.linear2(self.dropout(self.activation(self.linear1(x))))
        x = skip + self.dropout2(x)
        if not self.pre_norm:
            x = self.norm2(x)
        return x


class ACTDecoder(nn.Module):
    def __init__(self, config: ACTConfig):
        super().__init__()
        self.layers = nn.ModuleList([ACTDecoderLayer(config) for _ in range(config.n_decoder_layers)])
        self.norm = nn.LayerNorm(config.dim_model)

    def forward(
        self,
        x: Tensor,
        encoder_out: Tensor,
        decoder_pos_embed: Tensor | None = None,
        encoder_pos_embed: Tensor | None = None,
        memory_key_padding_mask: Tensor | None = None,
    ) -> Tensor:
        for layer in self.layers:
            x = layer(x, encoder_out, decoder_pos_embed=decoder_pos_embed,
                       encoder_pos_embed=encoder_pos_embed,
                       memory_key_padding_mask=memory_key_padding_mask)
        if self.norm is not None:
            x = self.norm(x)
        return x


class ACTDecoderLayer(nn.Module):
    def __init__(self, config: ACTConfig):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(config.dim_model, config.n_heads, dropout=config.dropout)
        self.multihead_attn = nn.MultiheadAttention(config.dim_model, config.n_heads, dropout=config.dropout)
        self.linear1 = nn.Linear(config.dim_model, config.dim_feedforward)
        self.dropout = nn.Dropout(config.dropout)
        self.linear2 = nn.Linear(config.dim_feedforward, config.dim_model)
        self.norm1 = nn.LayerNorm(config.dim_model)
        self.norm2 = nn.LayerNorm(config.dim_model)
        self.norm3 = nn.LayerNorm(config.dim_model)
        self.dropout1 = nn.Dropout(config.dropout)
        self.dropout2 = nn.Dropout(config.dropout)
        self.dropout3 = nn.Dropout(config.dropout)
        self.activation = get_activation_fn(config.feedforward_activation)
        self.pre_norm = config.pre_norm

    def maybe_add_pos_embed(self, tensor: Tensor, pos_embed: Tensor | None) -> Tensor:
        return tensor if pos_embed is None else tensor + pos_embed

    def forward(
        self,
        x: Tensor,
        encoder_out: Tensor,
        decoder_pos_embed: Tensor | None = None,
        encoder_pos_embed: Tensor | None = None,
        memory_key_padding_mask: Tensor | None = None,
    ) -> Tensor:
        skip = x
        if self.pre_norm:
            x = self.norm1(x)
        q = k = self.maybe_add_pos_embed(x, decoder_pos_embed)
        x = self.self_attn(q, k, value=x)[0]
        x = skip + self.dropout1(x)
        if self.pre_norm:
            skip = x
            x = self.norm2(x)
        else:
            x = self.norm1(x)
            skip = x
        x = self.multihead_attn(
            query=self.maybe_add_pos_embed(x, decoder_pos_embed),
            key=self.maybe_add_pos_embed(encoder_out, encoder_pos_embed),
            value=encoder_out,
            key_padding_mask=memory_key_padding_mask,
        )[0]
        x = skip + self.dropout2(x)
        if self.pre_norm:
            skip = x
            x = self.norm3(x)
        else:
            x = self.norm2(x)
            skip = x
        x = self.linear2(self.dropout(self.activation(self.linear1(x))))
        x = skip + self.dropout3(x)
        if not self.pre_norm:
            x = self.norm3(x)
        return x


def create_sinusoidal_pos_embedding(num_positions: int, dimension: int) -> Tensor:
    def get_position_angle_vec(position):
        return [position / np.power(10000, 2 * (hid_j // 2) / dimension) for hid_j in range(dimension)]

    sinusoid_table = np.array([get_position_angle_vec(pos_i) for pos_i in range(num_positions)])
    sinusoid_table[:, 0::2] = np.sin(sinusoid_table[:, 0::2])
    sinusoid_table[:, 1::2] = np.cos(sinusoid_table[:, 1::2])
    return torch.from_numpy(sinusoid_table).float()


def get_activation_fn(activation: str) -> Callable:
    if activation == "relu":
        return F.relu
    if activation == "gelu":
        return F.gelu
    if activation == "glu":
        return F.glu
    raise RuntimeError(f"activation should be relu/gelu/glu, not {activation}.")
